
public class Main {
    public static void main(String[] args) {
        Minesweeper minesweeper = new  Minesweeper();
    }
}